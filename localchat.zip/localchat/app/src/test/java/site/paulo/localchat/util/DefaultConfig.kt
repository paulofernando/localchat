package site.paulo.localchat.util

object DefaultConfig {
    const val EMULATE_SDK = 23
}
