package site.paulo.localchat.ui.utils

import android.content.Context
import android.view.View

val View.ctx: Context
    get() = context
